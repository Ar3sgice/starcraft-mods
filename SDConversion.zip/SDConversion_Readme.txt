Starcraft v1.12b Compatibility Only!  Any other versions will not work!

NOTES:

The Computer AI has not been updated to include any of the new units, nor will it ever.

CREDITS:

StealthyDeath - creator
King_Templar - infested zealot, templar, nexus idea + many other unused ideas and beta testing
Sikwatic - infested templar idea + many other unused ideas and beta testing
hidiho2 - beta testing
Nahotnoj - beta testing
Dark_Soul74 - beta testing

*All are names of the people on http://www.warboards.org.

KNOWN BUGS:
-The rally point on the Infested Nexus does not work.
- Random crashes while playing as Zerg.
- Using Windows XP SP2 may cause crashes, but you can still play the mod to it's fullest extent.
- Multiplayer games may cause crashing.

-----------------------------------------------------------------------------------

INSTALLATION:

Once you have downloaded it, place the file SDEdit.mpq in your starcraft folder. If you don't know where it is, it's usually C:\Program Files\Starcraft\.  It may be different depending on what letter your main drive is and how many you have too.  The SDConversion.exe can be placed anywhere and all you have to do is run it whenever you want to play the mod.


-----------------------------------------------------------------------------------

NEW UNITS:

	ZERG:

Zerg Kukulza
	Weapon Name/Damage/Type			Acid Spray/7 +1 per missile (damage*3 = total damage)/Explosive
	HP/Shields/Armor				200/None/2
	Build Time (in seconds)/Minerals/Gas/Supply	40/100/100/2
	Requires					Zerg Greater Spire
						Kukulza Aspect
	Morphed From				Zerg Mutalisk

Zerg Hunter
	Weapon Name/Damage/Type			Needle Spines/14 +2 Ground, 10 +1 Air/Explosive
	HP/Shields/Armor				135/None/1
	Build Time (in seconds)/Minerals/Gas/Supply	52/75/75/3
	Requires					Lair
						Morphing Aspect
	Morphed From				Zerg Hyrdralisk

Infested High Templar
	Weapon Name/Damage/Type			Psi Assault/20 +2 Ground/Normal
	HP/Shields/Armor				140/20/0
	Build Time (in seconds)/Minerals/Gas/Supply	66/150/200/3
	Requires					Infested Nexus
	Spells					Psionic Storm (Stacks)
	Built From					Infested Nexus

Infested Zealot
	Weapon Name/Damage/Type			Acid Blades/16 +2 +8 splash Ground/Normal
	HP/Shields/Armor				80/80/1
	Build Time (in seconds)/Minerals/Gas/Supply	41/125/25/3
	Requires					Infested Nexus
	Built From					Infested Nexus


-----------------------------------------------------------------------------------

	PROTOSS:

Protoss Mind Archon
	Weapon Name/Damage/Type			Psionic Shockwave/30 +5/Concussive
	HP/Shields/Armor				50/250/2
	Build Time (in seconds)/Minerals/Gas/Supply	93/250/200/5
	Requires					Templar Archives
						Arbiter Tribunal
	Spells					Recall
						Mind Control
	Built From					Gateway

Protoss Templar Warrior
	Weapon Name/Damage/Type			Psi Assult/25 +2/Explosive
	HP/Shields/Armor				75/125/2
	Build Time (in seconds)/Minerals/Gas/Supply	60/75/225/3
	Requires					Templar Archives
						Fleet Beacon
	Spells					Psionic Storm
						Hallucination
						Disruption Web
	Built From					Gateway

Protoss Gunship
	Weapon Name/Damage/Type			Tormentor Missiles/6 +1 per missile (damage*11 = total damage) Air/Normal
	HP/Shields/Armor				75/175/1
	Build Time (in seconds)/Minerals/Gas/Supply	86/250/150/5
	Requires					Fleet Beacon
	Built From					Stargate

Protoss Phase Shifter
	Weapon Name/Damage/Type			Phase Disruptor/20 +2 Long Range Ground, Air/Explosive
						Anti-Matter Missiles/4 +1 per missile (damage*10 = total damage) Close Range Ground/Explosive
	HP/Shields/Armor				60/200/2
	Build Time (in seconds)/Minerals/Gas/Supply	73/275/200/4
	Requires					Cybernetics Core
						Citadel of Adun
						Phase Shift
	Built From					Gateway


-----------------------------------------------------------------------------------

	TERRAN:

Terran Sniper
	Weapon Name/Damage/Type			C-37 Missile Rifle/70 +10/Explosive
	HP/Shields/Armor				20/100/4
	Build Time (in seconds)/Minerals/Gas/Supply	93/225/300/6
	Requires					Engineering Bay
						Starbase
						Science Facility with attached Covert Ops
						Science Facility with attached Physics Lab
	Spells					Cloak
						Lockdown
						Yamato Gun
	Built From					Barracks

Terran Stim Ghost
	Weapon Name/Damage/Type			C-10 Canister Rifle/15 +1/Concussive
	HP/Shields/Armor				60/None/1
	Build Time (in seconds)/Minerals/Gas/Supply	30/25/75
	Requires					Academy
						Engineering Bay
						Armory
	Spells					Stim Packs
						EMP Shockwave
	Built From					Barracks

Terran Shield Marine
	Weapon Name/Damage/Type			Gauss Rifle/7 +2/Normal
	HP/Shields/Armor				50/50/1
	Build Time (in seconds)/Minerals/Gas/Supply	50/100/50/2
	Requires					Academy
						Science Facility
						Engineering Bay
	Spells					Stim Packs
	Built From					Barracks

Terran Phoenix
	Weapon Name/Damage/Type			Fire Rockets/4 +1 per rocket (damage*6 = total damage)/Explosive
	HP/Shields/Armor				200/None/1
	Build Time (in seconds)/Minerals/Gas/Supply	73/325/100/4
	Requires					Starbase
						Science Facilty
	Spells					Disruption Web
	Built From					Starport


-----------------------------------------------------------------------------------

NEW BUILDINGS:

	TERRAN:

Terran Starbase
	HP/Shields/Armor				1000/None/1
	Build Time (in seconds)/Minerals/Gas		100/250/150
	Requires					Starport
	Miscellaneous				Provides 8 Supplies
						Resource depot
	Used For					Faster Expanding (Does not build SCVS)
						Unit Requirement
						Building and Yamato Gun Upgrades

	ZERG:

Infested Nexus
	HP/Shields/Armor				1500/50/1
	Build Time (in seconds)/Minerals/Gas		120/400/300
	Requires					Hive
						Queen's Nest
	Used For					Building Infested Templars and Zealots
						Researching Psionic Storm


-----------------------------------------------------------------------------------

NEW UPGRADES/TECHNOLOGIES
:
	Zerg
		- Kukulza Aspect
			Mineral/Cost			250/250
			Reserached From			Greater Spire
		- Building Carapace
			Mineral/Cost			100/100  +50/50 per upgrade
			Upgraded From			Evolution Chamber
		- Building Attacks
			Mineral/Cost			100/100  +50/50 per upgrade
			Upgraded From			Evolution Chamber
		- Psionic Storm
			Mineral/Cost			200/200
			Reseached From			Infested Nexus

	Terran
		- Yamato Gun Damage
			Mineral/Cost			100/100  +100/100 per upgrade
			Upgraded From			Starbase
		- Building Armor
			Mineral/Cost			100/100  +50/50 per upgrade
			Upgraded From			Starbase
		- Building Weapons
			Mineral/Cost			100/100  +50/50 per upgrade
			Upgraded From			Starbase
		- Disruption Web
			Mineral/Cost			200/200
			Reserached From			Control Tower

	Protoss
		- Phase Shift
			Mineral/Cost			300/300
			Reserached From			Citadel of Adun
		- Building Plates
			Mineral/Cost			100/100  +50/50 per upgrade
			Upgraded From			Cybnerectics Core
		- Building Weapons
			Mineral/Cost			100/100  +50/50 per upgrade
			Upgraded From			Cybernectics Core

-----------------------------------------------------------------------------------

MISCELLANEOUS CHANGES:

ZERG:
	Cocoon:
		- Now has air armor.
	Drone:
		- Attack can be upgraded.
	Queen:
		- Removed Infest Command Center ability.
	Lair:
		- Provides 5 supplies from 1.
	Hive:
		- Provides 9 supplies from 1.
	Other:
		- Buildings can be upgraded at the Evolution Chamber.
		- Lurker Aspect renamed to Morphing Aspect.
		- Lurker Egg renamed to Morphing Egg.
		- Can now build Infested Command Centers from a Drone.
		- New Icon for Morphing Aspect.

TERRAN:
	Valkyrie:
		- Has a 6.25% chance of increasing its speed while moving.
		- Added ground attack.
		- Damage increase to 7 per missile.
		- Requires a Starbase as well as the Armory.
		- Increased HP to 250.
		- Build time increased.
		- Increased cost to 300 minerals and 150 gas.
		- New ability - Afterburners - Increases speed and attack rate for 10 HP. (Basically Stim Packs)
	Wraith:
		- Now uses Burst Lasers for air attacks and Gemini Missiles for ground.
	Siege Tank:
		- Tank (Tank Mode) can now attack air.
	SCV:
		- Attack can be upgraded.
	Ghost:
		- Increased HP to 75
		- Increased cost to 50 minerals and 125 gas.
		- Renamed to Nuclear Ghost
	Yamato Gun:
		- Increases damage by 50 per upgrade at the Starbase.
	Missile Turret:
		- Added close ranged ground attack.
	Bunker:
		- Increased capacity to 6.
	Other:
		- Melee AI updated to include Terran Starbase.
		- Buildings can be upgraded at the Starbase.

PROTOSS:
	Scout:
		- Now uses Dual Photon Blasters for air attacks and Anti-Matter Missiles for ground.
		- Decreased build time
		- Decreased cost to 250 minerals.
	Corsair:
		- Can now attack ground.
	Probe:
		- Attack can be upgraded.
	Arbiter:
		- Attack damage increased to 15.
		- Attack cooldown decreased.
	Interceptor:
		- Attack damage increased to 8.
	Carrier:
		- Increased range from which a carrier can launch interceptors.
	Other:
		- Buildings can be upgraded at the Cybernetics Core.

MISCELLANEOUS:
		- 2 new player colors. Light Green and Light Blue
		- Tileset dependant minerals (minerals change color depending on tileset).
			Ash World - Red
			Badlands - Teal
			Desert - Black
			Ice - Blue
			Installation - Blue
			Jungle - Green
			Space - Grey
			Twilight - Purple
		- New title screen.
		- Other slight miscellaneous graphic changes.
		- 1.12b compatibility.
		- Computer AIs now has a slight increase in difficulty.  On island maps, it has been increased slightly more then on the
		non island maps.  The AI has also been updated to include the building upgrades and will research them during the
		game.


-----------------------------------------------------------------------------------

TROUBLESHOOTING

	Q. I get an error saying:

		Starcraft was unable to open a required file.  If this problem persists, try
		unistalling and reinstaling Starcraft using the program "SETUP.EXE" on the
		Starcraft CD-ROM.

		The problem occured while trying to load a file
			custom\mgpatch.mgd
			The system cannot find the file specified.

	A. Make sure the the SDEdit.mpq was not renamed and is in your main Starcraft folder.  If you don't know where it is, it's usually C:\Program Files\Starcraft\ or D:\Games\Starcraft\.  It may be different depending on what letter your drive is and how many you have too.


	Q. Does it work on Mac or Linux?

	A. Unfortunately no, because it only modifies PC files.


	Q. I get an error saying that my CD is not in the CD Drive.

	A. If you are using a No-CD Crack then it will not work.


-----------------------------------------------------------------------------------
StealthyDeath