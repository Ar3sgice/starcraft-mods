This file was downloaded at CreepColony's Skillful Starcraft!
Come to my site for hacks, maps, strategy, games, animations, bots, Starcraft music, utilities, StarEdit stuff, mods, conversions, tricks, glitches, and more!  Updated daily!  Don't forget to vote!

www.creepcolony.com

_______________________________________________________________________

Versus Version 1.5     

             ***THE BASIC REASON FOR CREATING VERSUS***
     
     You may be asking, "Why release all of you're TC's in one?"  The answer is
so that my TC's can be played without one taking over one aspect of another.  Say
you're playing the game and you checked a checkmark by the two conversions you wanted
and gasp and growl, The icons or wireframes of PokeCraft aren't working because ChronoCraft's
are overriding them.  Another reason is that I wanted to make some sort of special release..a special 
edition, and this is the best way I know how.  Anyway, that's the scoop.  Have fun, and look below for
what's new (under the notes for the current release.

******************************************************************************************************



                       NOTES FOR 1.5

      Not many new additions this time, but still I think it's comming along well.  The sounds from the 
origional tc's have been put into this one as well as a complete sohnd conversion for RYU/Ghost.
See TERRAN UNITS to find out exactly what's been changed graphically.  NOTE: if you would like to 
be on my maililng list go to my homepage and find out how.  http://www.angelfire.com/ri/Ydoc/index.html


                      NOTES FOR PREVIEW

	Alright, I know I know it's about time this thing is released.  Well Versus
is now underway and hopefully soon I can have the first version out for download.
Right now this is all of the convertable pointers.  Versus, as you may know, will be 
a combo of all of the three previous conversions including bug fixes and new characters
that weren't in the origionals.  Also a note on POKECRAFT.  I now have a homepage and
the problems I had sending PokeCraft Final were fixed a while back, but I don't remember
if Infoceptor posted the info or not.  POKECRAFT FINAL has been on my homepage for
quite a while now, and if you would like to download it go to 

http://www.angelfire.com/ri/Ydoc/index.html

This page houses more than just my starcraft TC's.

	
*****************************************************************************************

                	***What's In version 1.0***

-Pointers

regular cursor-Pidgy
Neutral-robot from MegaMan
attack enemy-cubone
attack friend-Chrono surprised
nothing attack-Earthworm Jim
scroll right-TaTa (from Chrono Trigger)
Scroll left- ProtoMan

-MegaNintenCraft(Terrans)          (All BUT RYU Have Multiplayer colors)

Ryu-Ghost   (street Fighter Alpha 2 graphics)
Battlecruiser-Lavos (taken from Lavos addon for ChronoCraft)
Science Vessel-Dr. Wiley
Drop Ship-Kirby Warp Star (origionally Superman
Marine- MegaMan
Firebat-FireMan
Vulture-Edger on a Chocobo
Siege Tank-Violator(seige mode not yet fixed)
Spider Mine-Kirby
SCV-Mario
Bunker-Robot
Command center-Wily Skull bot
Nuke missle-Nukebot
Barracks-Bowser's Castle

-ChronoCraft (Protoss)

(may have a few graphical problems that will be worked out.
if they exist they will be minimal)

Stasis-Dead soldier
Carrier-Floating city of zeal
scout-Chrono on a Dactyl
Zealot-Frog
Templar-Magus
PsiStorm spell-Ayla attack
Prism-Magus statue
Warp-Magus Castle
Gateway-Lucca transporter
Nexus-large robo and lucca creating robos
Probe-Robo
Pylon-fountain from the fair
Archon-Lucca
Arbiter-Bekklar(little clown head and hands in the tent at the melinal Fair.)
Reaver-Marl
Robotics facility-Computer
Observer-Chrono
cybernetics core-The Fair
Citadel of Adun-Big Crater
Assimilator-cave band
Sheild Battery - Spekkio
Forge-Humanoid Lavos
Archives-ChronoTrigger Logo

-PokeCraft (Zerg)

drone-Geodude(new birth update and now exists in the building graphics)
mutalisk-voltorb
larva-caterpie
sunken colony-wartortle
spore colony-Blastoise
creep colony- squirtle
cocoon-metapod
hatchery-pokeball
lair-bigger pokeball + pokemon logo
Hive-three pokeballs + MewTwo
Cerebrat-Snorlax
Queen Nest-PokeCenter(new pokecenter)
egg-pokeball
Ultralisk-Bulbasaur
Guardian-Electrode
spire-team rocket
Ultralisk Cavern-Pokemon Gym
Overlord-Koffing
zergling-Pikachu
Queen-Gravler
scourge-Zubat
Hydralisk Den-Pokecenter desk
Greater Spire-Greater Rocket
Overmind with shell-Starmie
Overmind without shell-Staryu
Defiler-Psyduck
Extractor-DugTrio




Until next Versus update
-Ydoc Nameloc (comments? e-mail me at Ryoga98@excite.com)